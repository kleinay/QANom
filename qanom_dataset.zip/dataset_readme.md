# QANom 2020 Dataset

This folder contains the annotations collected for the paper 
*QANom: Question-Answer driven SRL for Nominalizations* (COLING 2020).

QANom annotate verb-derived nominalizations with Question-Answer driven Semantic Role Labeling (QA-SRL) annotations.  
Each predicate - verb-derived noun that refers to some "verb"-related event,
is annotated with question-answer pairs capturing the arguments of that predicate 
(that is, the participants in the event e.g. agent, recipient, time, etc.).

The QANom dataset is comprised of two source corpora half-by-half - (1) Wikinews and (2) Wikipedia. 
For the train set, we annotated a sample of 8K sentences from the train partition of 
[QA-SRL Bank 2.0](https://github.com/uwnlp/qasrl-bank) 
(*Large-Scale QA-SRL Parsing*, FitzGeralds et. al., 2018).
For the gold-set (dev + test), we annotated the same sentences as in 
[QA-SRL Gold Standard](https://github.com/plroit/qasrl-gs) 
(*Controlled Crowdsourcing for High-Quality QA-SRL Annotation*, Roit et. al., 2020), 
which is also sampled from the dev and test partitions of QA-SRL Bank 2.0. 

A train-set sentence was annotated by a single trained worker, 
while a gold-set sentence was annotated by a pipeline of 3 trained workers. 
Overall, seven trained workers participated in creating the dataset.  
 
## Directory high-level structure

* dataset
    * train.csv
    * dev.csv
    * test.csv
    * train-set
        * ... 
    * gold-set
        * ...

The top-level files (`train.csv`,`dev.csv`,`test.csv`) contain all the data.
If a split by domain is required (Wikinews vs. Wikipedia), the `train-set` and `gold-set` folders 
contain the corresponding files for that.

## Data Format

The data files are all Comma Separated CSV files, 
mostly following and slightly modifying the [QA-SRL Gold Standard format](https://github.com/plroit/qasrl-gs#data-format).
The QANom format includes the following headers:


1. qasrl_id - Sentence identifier. Same id is used in QA-SRL Bank and QA-SRL Gold Standard.
2. sentence - Sentence string, pretokenized (joined with space).
3. target_idx - index of target predicate, i.e. the nominalization, in the sentence.
4. key - `qasrl_id + "_" target_idx`. A global unique identifier per target. 
5. noun - the target predicate (surface).
6. worker_id - each worker is mapped into an anonymous worker-id.
7. is_verbal - boolean, the "predicate-detection" annotation decision - whether or not this noun, in context, 
carry a ``verbal'' meaning.   
8. question - The question representing the role.
9. answer - Multiple answer spans, separated by: ~!~. Each answer is a contigious span of tokens that depicts an argument for the role.
10. answer_range - Multiple token ranges, separated by: ~!~. Each range corresponds to the answer span in the same position in the answer column, and is formatted with INCLUSIVE_START:EXCLUSIVE_END token indices from the sentence.

The following fields are taken from the the QA-SRL question template, as parsed by the QASRL state-machine. 

11. wh - The WH question word
12. aux - The Auxilliary slot
13. subj - The subject placeholder (someone or something)
14. obj - The direct object placeholder (someone or something)
15. prep - The preposition used for the indirect object
16. obj2 - The indirect object placeholder (someone or something)
17. is_negated - Boolean, detects if there is a negation in the question
18. is_passive - Boolean, detects if passive voice is used in the question
19. verb_prefix - An auxilary field for special passivisation prefixes ("be", "being") preceding the verb 
20. verb_slot_inflection - A marker for the morphological inflection of the verb (e.g. "Past", "Stem", "PresentParticiple") 

Converting between this QANom format (or the similar QA-SRL Gold Standard format) 
and the [QA-SRL Bank 2.0 JSON-lines data format](https://github.com/uwnlp/qasrl-bank/blob/master/FORMAT.md) 
can be done with [this script](https://github.com/kleinay/QANom/blob/master/qanom/annotations/qasrlv2_jsonl.py).